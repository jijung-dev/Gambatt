import { ActionRowBuilder, ButtonBuilder, ButtonStyle } from "discord.js";

// -------------------- BUTTON BUILDERS --------------------

function GetPrevButton(disabled = false, user) {
    return new ButtonBuilder()
        .setCustomId(`prev_page|${user.id}`)
        .setLabel("◀️")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(disabled);
}

function GetNextButton(disabled = false, user) {
    return new ButtonBuilder()
        .setCustomId(`next_page|${user.id}`)
        .setLabel("▶️")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(disabled);
}

function GetPageButtons(isFirstPage, isLastPage, user) {
    return new ActionRowBuilder().addComponents(
        GetPrevButton(isFirstPage, user),
        GetNextButton(isLastPage, user)
    );
}

// -------------------- EXPORTS --------------------

export { GetPrevButton, GetNextButton, GetPageButtons };
